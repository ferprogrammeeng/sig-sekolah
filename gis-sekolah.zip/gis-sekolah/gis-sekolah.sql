-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2022 at 06:55 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gis-sekolah`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sekolah`
--

CREATE TABLE `tbl_sekolah` (
  `id_sekolah` int(11) NOT NULL,
  `nama_sekolah` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `status_sekolah` varchar(255) DEFAULT NULL,
  `kepala_sekolah` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `ket` text DEFAULT NULL,
  `gambar` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_sekolah`
--

INSERT INTO `tbl_sekolah` (`id_sekolah`, `nama_sekolah`, `alamat`, `status_sekolah`, `kepala_sekolah`, `latitude`, `longitude`, `ket`, `gambar`) VALUES
(4, 'SMA Negeri 2 Pekanbaru', 'Jl. Nusa Indah No.4, Labuh Baru Tim., Kec. Payung ...', 'Negri', 'Kepsek', '0.5213699835372613', '101.43149846634856', 'Sekolah Favorit', ''),
(5, 'SMA Negeri 10 Pekanbaru', 'Jl. Bukit Barisan No.7, Tengkerang Tim., Kec. Tenayan Raya, Kota Pekanbaru, Riau 28131', 'Negri', 'Kepsek', '0.49231255376086897', '101.48638820867835', 'Sekolah Favorit', ''),
(6, 'SMAN 8 Pekanbaru State High School', 'Jl. Abdul Muis No.14, Cinta Raja, Kec. Sail, Kota Pekanbaru, Riau 28127', 'Negri', 'Budi M.Pd', '0.5092542951735738 ', ' 101.45879955839085', 'Sekolah Favorit', ''),
(7, 'Sekolah Menengah Kejuruan Negeri 3', 'Jl. Dr. Sutomo No.110, Suka Mulia, Kec. Sail, Kota Pekanbaru, Riau 28166', 'Negri', 'Kepsek', '0.5223078538624405', '101.45591322586438', 'Sekolah Favorit', ''),
(11, 'SMA Santa Maria Pekanbaru', 'GF75+V3C, Jl. Ronggo Warsito Gobah, Suka Maju, Kec. Sail, Kota Pekanbaru, Riau 28132', 'Negri', '--', '0.5146984564304692', ' 101.45764909702933', 'Sekolah Favorit', '2022-10-12_(1)1.png'),
(10, 'SMK FARMASI IKASARI', 'Jl. Bangau Sakti Jl. Mawar No.98, Simpang Baru, Kec. Tampan, Kota Pekanbaru, Riau 28292', 'Swasta', '---', '0.4774206966334798', ' 101.37156801052399', 'Sekolah Favorit', '2022-10-12_(1).png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_user`, `username`, `password`) VALUES
(3, 'admin', 'admin123', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_sekolah`
--
ALTER TABLE `tbl_sekolah`
  ADD PRIMARY KEY (`id_sekolah`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_sekolah`
--
ALTER TABLE `tbl_sekolah`
  MODIFY `id_sekolah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
