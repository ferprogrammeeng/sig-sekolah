<!--- footer-btm ---->
<div class="footer-btm wow fadeInLeft animated" data-wow-delay=".5s"  style="background-color:grey">
	<div class="container"  style="background-color:grey">
		<div class="navigation"  style="background-color:grey">
			<nav class="navbar navbar-default"  style="background-color:grey">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header"  style="background-color:grey">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil bg-secondary" id="bs-example-navbar-collapse-1" style="background-color:grey">
					<nav class="cl-effect-1 bg-secondary">
						<ul class="nav navbar-nav bg-secondary">
							<li><a href="<?= base_url('webgis') ?>">Home</a></li>
							<li><a href="<?= base_url('webgis/list_sekolah') ?>">List Sekolah</a></li>
							<li><a href="<?= base_url('webgis/about') ?>">About</a></li>
							<div class="clearfix"></div>
						</ul>
					</nav>
				</div><!-- /.navbar-collapse -->
			</nav>
		</div>

		<div class="clearfix"></div>
	</div>
</div>
<!--- /footer-btm ---->
<br>
