<body>
	<!-- top-header -->
	<div class="top-header " style="background-color:red">
		<div class="container">
			<ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
				<li class="hm"><a href="index.html"><i class="fa fa-home"></i></a></li>
				<li class="prnt"><a href="javascript:window.print()">Sistem Informasi Geografi</a></li>

			</ul>
			<ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s">
				<li class="tol">Toll Number : 123-4568790</li>
				<li class="sigi"><a href="<?= base_url('login') ?>">Login</a></li>
			</ul>
			<div class="clearfix"></div>
		</div>
	</div>
	<!--- /top-header ---->
	<!--- header ---->
	<div class="header bg-secondary" style="background-color:#DCDCDC">
		<div class="container bg-secondary">
			<div class="logo wow fadeInDown animated bg-secondary " data-wow-delay=".5s">
				<a href="index.html">GIS <span>Sekolah Kota Pekanbaru</span></a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!--- /header ---->
