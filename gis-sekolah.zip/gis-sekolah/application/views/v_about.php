<div class="row">
	<div class="col-sm-12">
		<div class="panel panel-primary">
			<div class="panel-heading"> About</div>
			<div class="panel-body">


				<h1>NIM : </h1>
				<h1>Nama : </h1>
				<h1>Kelas : </h1>




			</div>
		</div>
	</div>
</div>
